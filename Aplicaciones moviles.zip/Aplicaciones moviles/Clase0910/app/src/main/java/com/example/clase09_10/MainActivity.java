package com.example.clase09_10;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private EditText editNumero;
    private Spinner spOpciones;
    private Button btnCalcular, btnCancelar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        editNumero=findViewById(R.id.edit_numero);
        spOpciones=findViewById(R.id.sp_opciones);
        btnCancelar=findViewById(R.id.btn_cancelar);
        btnCalcular=findViewById(R.id.btn_calcular);
        String[] opciones={"antecesor", "sucesor"};
        ArrayAdapter<String>  x=new ArrayAdapter<>( this, android.R.layout.simple_spinner_item,opciones);
        spOpciones.setAdapter(x);
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int numero;
                try {
                    numero=Integer.parseInt(editNumero.getText().toString());
                    String valorOpcion=spOpciones.getSelectedItem().toString();
                    String resultado;
                    Metodos a=new Metodos();
                    if (valorOpcion.equals("antecesor"))
                    {
                        resultado=numero+" su antecesor es"+a.antecesor(numero);
                    }
                    else
                    {
                        resultado=numero+" su sucesor es"+a.sucesor(numero);
                    }
                    Toast.makeText(MainActivity.this, "debe ingresar un n° ", Toast.LENGTH_SHORT).show();
                    Intent i=new Intent(getApplicationContext(), ResultadoActivity.class);
                    i.putExtra("valorEnviado",resultado);
                    startActivity(i);
                }
                catch (NumberFormatException ex)
                {
                    Toast.makeText(MainActivity.this, "debe ingresar un n° ", Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systenBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systenBars.left, systenBars.top, systenBars.right, systenBars.bottom);
            return insets;
        });

    }
}