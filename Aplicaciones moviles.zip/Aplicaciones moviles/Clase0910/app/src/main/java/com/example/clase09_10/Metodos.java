package com.example.clase09_10;

public class Metodos {
    public int antecesor(int valor)
    {
        valor--;
        return valor;
    }
    public int sucesor(int valor)
    {
        valor++;
        return valor;
    }

}
