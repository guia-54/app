package com.example.clase09_10;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ResultadoActivity extends AppCompatActivity {
    private TextView tvMostrar;
    private Button btnVolver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_resultado);
        tvMostrar = findViewById(R.id.tv_mostrar);
        btnVolver = findViewById(R.id.btn_volver);
        String valorRecibido=getIntent().getStringExtra("valor Enviado");
        tvMostrar.setText(valorRecibido);
        btnVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systenBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systenBars.left, systenBars.top, systenBars.right, systenBars.bottom);
            return insets;
        });

    }
}